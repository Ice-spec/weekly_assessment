package com.example.student_profile

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.student_profile.databinding.StudentProfileBinding

class StudentProfileAdapter(val profiles: List<Student_ProfileModel>): RecyclerView.Adapter<StudentProfileAdapter.ViewHolder>(){

    class ViewHolder(val binding: StudentProfileBinding): RecyclerView.ViewHolder(binding.root){
        fun bind(profile: Student_ProfileModel ){
            binding.firstName.text = profile.firstName
            binding.lastName.text = profile.lastName
            binding.imageView.drawable
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding: StudentProfileBinding = StudentProfileBinding.inflate(LayoutInflater.from(parent.context))
            return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val profile = profiles.get(position)
        holder.bind(profile)
    }

    override fun getItemCount(): Int {
        return profiles.size
    }
}

