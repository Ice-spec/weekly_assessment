package com.example.student_profile

data class Student_ProfileModel(
    val firstName: String,
    val lastName: String,
    val ImageView: Int
)
