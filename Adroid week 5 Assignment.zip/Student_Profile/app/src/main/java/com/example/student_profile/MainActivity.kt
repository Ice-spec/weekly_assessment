package com.example.student_profile

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.student_profile.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var myProfileAdapter: StudentProfileAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val profiles: List<Student_ProfileModel> = listOf(
            Student_ProfileModel("Janifer", "Okoro", 1),
            Student_ProfileModel("Dennis", "Gabriel", 2),
            Student_ProfileModel("Asena", "Dandy", 3)
        )
        myProfileAdapter= StudentProfileAdapter(profiles)
        binding.recyclerView.adapter = myProfileAdapter
    }
}